
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Assig4 implements LoginInterface, VoteInterface {

    private JFrame theWindow;
    private String vFile, bFile;
    private Voter Vv;
    private LoginPanel loginP;
    private BallotPanel ballotP;

    private JButton login, login3;
    private JLabel label,label2, label3;
    

    public Assig4(String votersFile, String ballotsFile) {
        bFile = ballotsFile;
        vFile = votersFile;


        theWindow = new JFrame("Assig4");
		theWindow.setLayout(new FlowLayout());
        //theWindow.setLayout(new GridLayout(0, 1,1,1));
        theWindow.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        theWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        

        label = new JLabel("Welcome to E-Vote");
        label.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 30));
        //label.setHorizontalAlignment(SwingConstants.CENTER);
        //label.setVerticalAlignment(SwingConstants.CENTER);

        login = new JButton("Click to Login");
        login.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 30));
        login.addActionListener(new LoginListener());

        theWindow.add(label);
        theWindow.add(login);
        theWindow.pack();
        theWindow.setVisible(true);
        
        
        ballotP = new BallotPanel(bFile, this);
    }

    public void setVoter(Voter newVoter) {
        
        Vv = newVoter;

        theWindow.remove(loginP);
        theWindow.remove(label);
      //  theWindow.pack();

/*
        label3 = new JLabel("Welcome to E-Vote");
        label3.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 30));
        label3.setHorizontalAlignment(SwingConstants.CENTER);
        label3.setVerticalAlignment(SwingConstants.CENTER);

        login3 = new JButton("Click to Login");
        login3.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 30));
        login3.addActionListener(new LoginListener());

        theWindow.add(label3);
        theWindow.add(login3);
*/

        label2 = new JLabel(Vv.voterName + " please make your choices");
        label2.setFont(new Font("Serif", Font.ITALIC + Font.BOLD, 30));
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setVerticalAlignment(SwingConstants.CENTER);

		//theWindow.setLayout(new GridLayout(0, 1,10,10));

        theWindow.add(label2);
        
        theWindow.add(ballotP);
        theWindow.pack();

    }

    public void voted() {
        // voterobject
        Vv.vote();
        //save
        Voter.saveVoter(vFile, Vv);

        theWindow.remove(label2);
        theWindow.remove(ballotP);
        JOptionPane.showMessageDialog(theWindow, Vv.voterName + ", thanks for voting!");
        
        // go back to login view
        theWindow.add(label);
        theWindow.add(login);
        
        theWindow.pack();
  
    }

    private class LoginListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            loginP = new LoginPanel(vFile, Assig4.this);
            theWindow.remove(login);

            // this is where that stupid button to vote should be

            theWindow.add(loginP);

            // reset the ballots when login is called
            ballotP.resetBallots();
            theWindow.pack();
        }
    }

    public static void main(String[] args) {
        
        new Assig4(args[0],args[1]);
    }

}
